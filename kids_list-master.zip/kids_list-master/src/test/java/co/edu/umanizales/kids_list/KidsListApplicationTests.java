package co.edu.umanizales.kids_list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KidsListApplicationTests {

    @Test
    void contextLoads() {
    }

}
