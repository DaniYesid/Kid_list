package co.edu.umanizales.kids_list;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KidsListApplication {

    public static void main(String[] args) {
        SpringApplication.run(KidsListApplication.class, args);
    }

}
